package com.omeryilmaz.myapplication.model.topscorers

import com.google.gson.annotations.SerializedName

data class TopScorersResponse(
    @SerializedName("response")
    var response: List<TopScorersResponseModel>
)