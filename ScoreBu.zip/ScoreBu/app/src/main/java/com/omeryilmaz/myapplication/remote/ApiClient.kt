package com.omeryilmaz.myapplication.remote

import com.omeryilmaz.myapplication.model.standing.StandingResponse
import com.omeryilmaz.myapplication.model.topscorers.TopScorersResponse
import io.reactivex.Single
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory

class ApiClient {

    companion object{
        const val BASE_URL = "https://api-football-v1.p.rapidapi.com/v3/"
    }

    private val api = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
        .client(getOkhttpClient())
        .build()
        .create(ApiService::class.java)

    private fun getOkhttpClient(): OkHttpClient {
        val client = OkHttpClient.Builder()
        client.addInterceptor(RequestInterceptor())
        return client.build()
    }

    fun getStanding(): Single<StandingResponse> {
        return api.getStanding()
    }

    fun getTopScorers(): Single<TopScorersResponse>{
        return api.getTopScorers()
    }
    fun getAssists(): Single<TopScorersResponse>{
        return api.getTopAssists()
    }
    fun getYellowCard(): Single<TopScorersResponse>{
        return api.getYellowCard()
    }
    fun getRedCard(): Single<TopScorersResponse>{
        return api.getRedCard()
    }
}