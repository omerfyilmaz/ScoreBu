package com.omeryilmaz.myapplication.model.topscorers

import com.google.gson.annotations.SerializedName

data class TopScorersResponseModel(
    @SerializedName("player")
    var player: PlayerResponseModel,
    @SerializedName("statistics")
    var statistics: ArrayList<PlayerStatisticsModel>
)