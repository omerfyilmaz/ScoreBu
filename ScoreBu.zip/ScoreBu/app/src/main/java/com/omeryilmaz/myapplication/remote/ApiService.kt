package com.omeryilmaz.myapplication.remote

import com.omeryilmaz.myapplication.model.standing.StandingResponse
import com.omeryilmaz.myapplication.model.topscorers.TopScorersResponse
import io.reactivex.Single
import retrofit2.http.GET

interface ApiService {


    @GET("standings?season=2022&league=203")
    fun getStanding(): Single<StandingResponse>

    @GET("players/topscorers?league=203&season=2022")
    fun getTopScorers(): Single<TopScorersResponse>

    @GET("players/topassists?league=203&season=2022")
    fun getTopAssists(): Single<TopScorersResponse>

    @GET("players/topyellowcards?league=203&season=2022")
    fun getYellowCard(): Single<TopScorersResponse>

    @GET("players/topredcards?league=203&season=2022")
    fun getRedCard(): Single<TopScorersResponse>


}