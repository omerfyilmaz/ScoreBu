package com.omeryilmaz.myapplication.model.standing

import com.google.gson.annotations.SerializedName

data class StandingTeamResponse(
    @SerializedName("rank")
    var rank: Int,
    @SerializedName("team")
    var team: TeamDetailsModel,
    @SerializedName("points")
    var points: Int,
    @SerializedName("goalsDiff")
    var goalsDiff: Int,
    @SerializedName("all")
    var all: TeamMatchDetail
)

