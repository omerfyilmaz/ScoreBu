package com.omeryilmaz.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.transition.Hold
import com.omeryilmaz.myapplication.databinding.ItemPlayerBinding
import com.omeryilmaz.myapplication.model.topscorers.TopScorersResponseModel

class AssistAdapter(private val topScorerList: ArrayList<TopScorersResponseModel>) : RecyclerView.Adapter<AssistAdapter.AssistAdapterViewHolder>() {

    val lastList = topScorerList
    class AssistAdapterViewHolder(val binding: ItemPlayerBinding): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AssistAdapterViewHolder {
        val binding = ItemPlayerBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return AssistAdapterViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AssistAdapterViewHolder, position: Int) {
        val player = lastList[position]
        holder.binding.tvAssists.visibility = View.VISIBLE
        holder.binding.tvPlayerName.text = player.player.name
        holder.binding.tvTeam.text = player.statistics[0].team.name
        holder.binding.tvAssists.text = player.statistics[0].goals.assists.toString()

        Glide
            .with(holder.itemView.context)
            .load(player.player.photo)
            .centerCrop()
            .placeholder(R.drawable.loading)
            .into(holder.binding.ivPlayer)
    }

    override fun getItemCount() = lastList.size

    fun updateList(newList: ArrayList<TopScorersResponseModel>){
        lastList.clear()
        lastList.addAll(newList)
        notifyDataSetChanged()
    }
}