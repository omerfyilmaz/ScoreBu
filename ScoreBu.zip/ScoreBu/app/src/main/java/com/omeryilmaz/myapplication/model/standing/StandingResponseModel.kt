package com.omeryilmaz.myapplication.model.standing

import com.google.gson.annotations.SerializedName

data class StandingResponseModel(
    @SerializedName("league")
    var league: StandingDetailModel
)
