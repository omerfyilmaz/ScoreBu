package com.omeryilmaz.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.omeryilmaz.myapplication.databinding.ItemPlayerBinding
import com.omeryilmaz.myapplication.model.topscorers.TopScorersResponseModel

class YellowCardAdapter(private val topScorerList: ArrayList<TopScorersResponseModel>) : RecyclerView.Adapter<YellowCardAdapter.YellowCardViewHolder>() {

    val lastList = topScorerList
    class YellowCardViewHolder(val binding: ItemPlayerBinding): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): YellowCardViewHolder {
        val binding = ItemPlayerBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return YellowCardViewHolder(binding)
    }

    override fun onBindViewHolder(holder: YellowCardViewHolder, position: Int) {
        val player = lastList[position]
        holder.binding.tvYellowCard.visibility = View.VISIBLE
        holder.binding.tvPlayerName.text = player.player.name
        holder.binding.tvTeam.text = player.statistics[0].team.name
        holder.binding.tvYellowCard.text = player.statistics[0].cards.yellow.toString()

        Glide
            .with(holder.itemView.context)
            .load(player.player.photo)
            .centerCrop()
            .placeholder(R.drawable.loading)
            .into(holder.binding.ivPlayer)
    }

    override fun getItemCount() = lastList.size

    fun updateList(newList: ArrayList<TopScorersResponseModel>){
        lastList.clear()
        lastList.addAll(newList)
        notifyDataSetChanged()
    }
}