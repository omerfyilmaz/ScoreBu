package com.omeryilmaz.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.omeryilmaz.myapplication.databinding.ItemPlayerBinding
import com.omeryilmaz.myapplication.model.topscorers.TopScorersResponseModel

class RedCardsAdapter(private val topScorerList: ArrayList<TopScorersResponseModel>) : RecyclerView.Adapter<RedCardsAdapter.RedCardsViewHolder>() {

    val lastList = topScorerList
    class RedCardsViewHolder(val binding: ItemPlayerBinding): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RedCardsViewHolder {
        val binding = ItemPlayerBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return RedCardsViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RedCardsViewHolder, position: Int) {
        val player = lastList[position]
        holder.binding.tvRedCard.visibility = View.VISIBLE
        holder.binding.tvPlayerName.text = player.player.name
        holder.binding.tvTeam.text = player.statistics[0].team.name
        holder.binding.tvRedCard.text = player.statistics[0].cards.red.toString()

        Glide
            .with(holder.itemView.context)
            .load(player.player.photo)
            .centerCrop()
            .placeholder(R.drawable.loading)
            .into(holder.binding.ivPlayer)
    }

    override fun getItemCount() = lastList.size

    fun updateList(newList: ArrayList<TopScorersResponseModel>){
        lastList.clear()
        lastList.addAll(newList)
        notifyDataSetChanged()
    }
}