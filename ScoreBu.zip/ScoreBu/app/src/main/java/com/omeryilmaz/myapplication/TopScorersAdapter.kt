package com.omeryilmaz.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.omeryilmaz.myapplication.databinding.ItemPlayerBinding
import com.omeryilmaz.myapplication.model.standing.StandingTeamResponse
import com.omeryilmaz.myapplication.model.topscorers.TopScorersResponse
import com.omeryilmaz.myapplication.model.topscorers.TopScorersResponseModel

class TopScorersAdapter(private val topScorerList: ArrayList<TopScorersResponseModel>) : RecyclerView.Adapter<TopScorersAdapter.TopScorersViewHolder>() {

    val lastList = topScorerList
    class TopScorersViewHolder(val binding: ItemPlayerBinding): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TopScorersViewHolder {
        val binding = ItemPlayerBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return TopScorersViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TopScorersViewHolder, position: Int) {
        val player = lastList[position]
        holder.binding.tvGoal.visibility = View.VISIBLE
        holder.binding.tvPlayerName.text = player.player.name
        holder.binding.tvTeam.text = player.statistics[0].team.name
        holder.binding.tvGoal.text = player.statistics[0].goals.totals.toString()

        Glide
            .with(holder.itemView.context)
            .load(player.player.photo)
            .centerCrop()
            .placeholder(R.drawable.loading)
            .into(holder.binding.ivPlayer)
    }

    override fun getItemCount() = lastList.size

    fun updateList(newList: ArrayList<TopScorersResponseModel>){
        lastList.clear()
        lastList.addAll(newList)
        notifyDataSetChanged()
    }
}