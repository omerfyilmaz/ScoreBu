package com.omeryilmaz.myapplication.remote

import com.bumptech.glide.RequestBuilder
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response

class RequestInterceptor : Interceptor {

    companion object{
        const val API_KEY = "23480db83dmsh4a89f1438cc689dp1b3eebjsnd39fcdbafe1f"
    }
    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()
        val requestBuilder = originalRequest.newBuilder().header("X-RapidAPI-Key", API_KEY)
        val request = requestBuilder.build()
        return chain.proceed(request)
    }
}