package com.omeryilmaz.myapplication.model.topscorers

import com.google.gson.annotations.SerializedName

data class PlayerStatisticsModel(
    @SerializedName("team")
    var team: TeamResponseModel,
    @SerializedName("goals")
    var goals: GoalsResponseModel,
    @SerializedName("cards")
    var cards: CardResponseModel
)
