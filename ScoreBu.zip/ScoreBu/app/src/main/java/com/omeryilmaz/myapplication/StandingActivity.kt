package com.omeryilmaz.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.recyclerview.widget.LinearLayoutManager
import com.omeryilmaz.myapplication.databinding.ActivityStandingBinding
import com.omeryilmaz.myapplication.model.standing.StandingDetailModel
import com.omeryilmaz.myapplication.model.standing.StandingResponse
import com.omeryilmaz.myapplication.model.standing.StandingResponseModel
import com.omeryilmaz.myapplication.model.standing.StandingTeamResponse
import com.omeryilmaz.myapplication.remote.ApiClient
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.observers.DisposableSingleObserver
import io.reactivex.schedulers.Schedulers

class StandingActivity : AppCompatActivity() {
    private lateinit var binding: ActivityStandingBinding

    private val apiClient = ApiClient()
    private val disposable = CompositeDisposable()
    val teamList = MutableLiveData<List<StandingResponseModel>>()
    val loadingStanding = MutableLiveData<Boolean>()
    private lateinit var standingAdapter: StandingAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStandingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        standingAdapter = StandingAdapter(arrayListOf())
        binding.rvStanding.adapter = standingAdapter
        binding.rvStanding.layoutManager = LinearLayoutManager(this)
        binding.rvStanding.setHasFixedSize(true)
        getLeagueStanding()
        observeLiveData()

        binding.ivBack.setOnClickListener {
            finish()
        }
    }

    private fun getLeagueStanding() {
        loadingStanding.value = true
        disposable.add(
            apiClient.getStanding()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(object : DisposableSingleObserver<StandingResponse>() {
                    override fun onSuccess(t: StandingResponse) {
                        teamList.value = t.response
                        loadingStanding.value = false
                        println("succes standing")
                    }

                    override fun onError(e: Throwable) {
                        println("error standing ${e.localizedMessage}")
                    }

                })
        )
    }

    private fun observeLiveData() {
        teamList.observe(this) { teamInfo ->
            teamInfo[0].let { standingResponseModel ->
                standingResponseModel.league.let { standingDetailModel ->
                    standingDetailModel.standings[0]
                }
                standingAdapter.updateList(standingResponseModel.league.standings[0])
            }
        }
    }
}