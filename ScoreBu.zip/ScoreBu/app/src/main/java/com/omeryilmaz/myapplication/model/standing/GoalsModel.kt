package com.omeryilmaz.myapplication.model.standing

import com.google.gson.annotations.SerializedName

data class GoalsModel(
    @SerializedName("for")
    var fora: Int,
    @SerializedName("against")
    var against: Int
)