package com.omeryilmaz.myapplication.model.standing

import com.google.gson.annotations.SerializedName

data class TeamMatchDetail(
    @SerializedName("played")
    var played: Int,
    @SerializedName("win")
    var win: Int,
    @SerializedName("draw")
    var draw: Int,
    @SerializedName("lose")
    var lose: Int,
    @SerializedName("goals")
    var goals: GoalsModel
)