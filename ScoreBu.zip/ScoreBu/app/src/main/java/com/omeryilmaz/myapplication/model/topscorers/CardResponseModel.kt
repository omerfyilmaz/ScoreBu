package com.omeryilmaz.myapplication.model.topscorers

import com.google.gson.annotations.SerializedName

data class CardResponseModel(
    @SerializedName("yellow")
    var yellow: Int,
    @SerializedName("red")
    var red: Int

)