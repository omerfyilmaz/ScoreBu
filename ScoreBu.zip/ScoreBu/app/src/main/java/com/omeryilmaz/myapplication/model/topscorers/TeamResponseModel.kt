package com.omeryilmaz.myapplication.model.topscorers

import com.google.gson.annotations.SerializedName

data class TeamResponseModel(
    @SerializedName("id")
    var id: Int,
    @SerializedName("name")
    var name: String,
    @SerializedName("logo")
    var logo:String
)