package com.omeryilmaz.myapplication.model.standing

import com.google.gson.annotations.SerializedName

data class StandingDetailModel(
    @SerializedName("id")
    var id: Int,
    @SerializedName("name")
    var name:String,
    @SerializedName("country")
    var country: String,
    @SerializedName("logo")
    var logo: String,
    @SerializedName("flag")
    var flag: String,
    @SerializedName("season")
    var season: Int,
    @SerializedName("standings")
    var standings: ArrayList<ArrayList<StandingTeamResponse>>
)
