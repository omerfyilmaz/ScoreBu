package com.omeryilmaz.myapplication.model.topscorers

import com.google.gson.annotations.SerializedName

data class GoalsResponseModel(
    @SerializedName("total")
    var totals: Int,
    @SerializedName("assists")
    var assists: Int
)