package com.omeryilmaz.myapplication

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.omeryilmaz.myapplication.databinding.ItemTeamBinding
import com.omeryilmaz.myapplication.model.standing.StandingTeamResponse

class StandingAdapter(private val standingList: ArrayList<StandingTeamResponse>): RecyclerView.Adapter<StandingAdapter.StandingViewHolder>() {

    private val list = standingList
    class StandingViewHolder(val binding: ItemTeamBinding): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StandingViewHolder {
        val binding = ItemTeamBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return StandingViewHolder(binding)
    }

    override fun onBindViewHolder(holder: StandingViewHolder, position: Int) {
        val teamInfo = list[position]

        if (position%2 == 0){
            holder.binding.cvRoot.setBackgroundResource(R.drawable.bg_item)
        }else{
            holder.binding.cvRoot.setBackgroundResource(R.drawable.bg_white_item)
        }
        holder.binding.tvRank.text = teamInfo.rank.toString()
        holder.binding.tvName.text = teamInfo.team.name
        holder.binding.tvGp.text = teamInfo.all.played.toString()
        holder.binding.tvW.text = teamInfo.all.win.toString()
        holder.binding.tvL.text = teamInfo.all.lose.toString()
        holder.binding.tvD.text = teamInfo.all.draw.toString()
        holder.binding.tvF.text = teamInfo.all.goals.fora.toString()
        holder.binding.tvA.text = teamInfo.all.goals.against.toString()
        if (teamInfo.goalsDiff < 0){
            holder.binding.tvGd.setTextColor(holder.itemView.context.getColor(android.R.color.holo_red_dark))
            holder.binding.tvGd.text = "-${teamInfo.goalsDiff}"
        }else if(teamInfo.goalsDiff > 0){
            holder.binding.tvGd.setTextColor(holder.itemView.context.getColor(android.R.color.holo_green_dark))
            holder.binding.tvGd.text = "+${teamInfo.goalsDiff}"
        }
        holder.binding.tvP.text = teamInfo.points.toString()

    }

    override fun getItemCount() = list.size

    fun updateList(newList: ArrayList<StandingTeamResponse>){
        list.clear()
        list.addAll(newList)
        notifyDataSetChanged()
    }
}