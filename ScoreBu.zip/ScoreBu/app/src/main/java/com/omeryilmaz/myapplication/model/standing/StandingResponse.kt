package com.omeryilmaz.myapplication.model.standing

import com.google.gson.annotations.SerializedName

data class StandingResponse(
    @SerializedName("response")
    var response: List<StandingResponseModel>
)
