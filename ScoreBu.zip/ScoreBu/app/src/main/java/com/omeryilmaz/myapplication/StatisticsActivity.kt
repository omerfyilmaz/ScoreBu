package com.omeryilmaz.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.lifecycle.MutableLiveData
import androidx.recyclerview.widget.LinearLayoutManager
import com.omeryilmaz.myapplication.databinding.ActivityStandingBinding
import com.omeryilmaz.myapplication.databinding.ActivityStatisticsBinding
import com.omeryilmaz.myapplication.model.standing.StandingResponse
import com.omeryilmaz.myapplication.model.standing.StandingResponseModel
import com.omeryilmaz.myapplication.model.topscorers.TopScorersResponse
import com.omeryilmaz.myapplication.model.topscorers.TopScorersResponseModel
import com.omeryilmaz.myapplication.remote.ApiClient
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.observers.DisposableSingleObserver
import io.reactivex.schedulers.Schedulers

class StatisticsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityStatisticsBinding

    private val apiClient = ApiClient()
    private val disposable = CompositeDisposable()
    val topScorerList = MutableLiveData<List<TopScorersResponseModel>>()
    val assistsList = MutableLiveData<List<TopScorersResponseModel>>()
    val yellowCardList = MutableLiveData<List<TopScorersResponseModel>>()
    val redCardList = MutableLiveData<List<TopScorersResponseModel>>()
    val loadingStatistics = MutableLiveData<Boolean>()
    private lateinit var topScorersAdapter : TopScorersAdapter
    private lateinit var yellowCardAdapter: YellowCardAdapter
    private lateinit var redCardsAdapter: RedCardsAdapter
    private lateinit var assistAdapter: AssistAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStatisticsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        topScorersAdapter = TopScorersAdapter(arrayListOf())
        binding.rvGoals.adapter = topScorersAdapter
        binding.rvGoals.layoutManager = LinearLayoutManager(this)
        binding.rvGoals.setHasFixedSize(true)
        assistAdapter = AssistAdapter(arrayListOf())
        binding.rvAssists.adapter = assistAdapter
        binding.rvAssists.layoutManager = LinearLayoutManager(this)
        binding.rvAssists.setHasFixedSize(true)
        yellowCardAdapter = YellowCardAdapter(arrayListOf())
        binding.rvYellowCard.adapter = yellowCardAdapter
        binding.rvYellowCard.layoutManager = LinearLayoutManager(this)
        binding.rvYellowCard.setHasFixedSize(true)
        redCardsAdapter = RedCardsAdapter(arrayListOf())
        binding.rvRedCard.adapter = redCardsAdapter
        binding.rvRedCard.layoutManager = LinearLayoutManager(this)
        binding.rvRedCard.setHasFixedSize(true)
        getLeagueStatistics()
        getRedCard()
        getYellowCard()
        getAssists()
        observeLiveData()

        binding.cvGoals.setOnClickListener {
            if (binding.rvGoals.visibility == View.GONE){
                binding.rvGoals.visibility = View.VISIBLE
            }else if(binding.rvGoals.visibility == View.VISIBLE){
                binding.rvGoals.visibility = View.GONE
            }
        }
        binding.cvAssists.setOnClickListener {
            if (binding.rvAssists.visibility == View.GONE){
                binding.rvAssists.visibility = View.VISIBLE
            }else if(binding.rvAssists.visibility == View.VISIBLE){
                binding.rvAssists.visibility = View.GONE
            }
        }

        binding.cvRedCard.setOnClickListener {
            if (binding.rvRedCard.visibility == View.GONE){
                binding.rvRedCard.visibility = View.VISIBLE
            }else if(binding.rvRedCard.visibility == View.VISIBLE){
                binding.rvRedCard.visibility = View.GONE
            }
        }
        binding.cvYellowCard.setOnClickListener {
            if (binding.rvYellowCard.visibility == View.GONE){
                binding.rvYellowCard.visibility = View.VISIBLE
            }else if(binding.rvYellowCard.visibility == View.VISIBLE){
                binding.rvYellowCard.visibility = View.GONE
            }
        }

        binding.ivBack.setOnClickListener {
            finish()
        }
    }

    private fun getLeagueStatistics(){
        loadingStatistics.value = true
        disposable.add(
            apiClient.getTopScorers()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(object : DisposableSingleObserver<TopScorersResponse>(){
                    override fun onSuccess(t: TopScorersResponse) {
                        topScorerList.value = t.response
                        loadingStatistics.value = false
                        println("succes standing")
                    }

                    override fun onError(e: Throwable) {
                        println("error statistics ${e.localizedMessage}")
                    }

                })
        )
    }

    private fun getAssists(){
        loadingStatistics.value = true
        disposable.add(
            apiClient.getAssists()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(object : DisposableSingleObserver<TopScorersResponse>(){
                    override fun onSuccess(t: TopScorersResponse) {
                        assistsList.value = t.response
                        loadingStatistics.value = false
                        println("succes standing")
                    }

                    override fun onError(e: Throwable) {
                        println("error statistics ${e.localizedMessage}")
                    }

                })
        )
    }

    private fun getYellowCard(){
        loadingStatistics.value = true
        disposable.add(
            apiClient.getYellowCard()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(object : DisposableSingleObserver<TopScorersResponse>(){
                    override fun onSuccess(t: TopScorersResponse) {
                        yellowCardList.value = t.response
                        loadingStatistics.value = false
                        println("succes standing")
                    }

                    override fun onError(e: Throwable) {
                        println("error statistics ${e.localizedMessage}")
                    }

                })
        )
    }

    private fun getRedCard(){
        loadingStatistics.value = true
        disposable.add(
            apiClient.getRedCard()
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(object : DisposableSingleObserver<TopScorersResponse>(){
                    override fun onSuccess(t: TopScorersResponse) {
                        redCardList.value = t.response
                        loadingStatistics.value = false
                        println("succes standing")
                    }

                    override fun onError(e: Throwable) {
                        println("error statistics ${e.localizedMessage}")
                    }

                })
        )
    }


    private fun observeLiveData() {
        topScorerList.observe(this) { topScorers ->
            topScorersAdapter.updateList(topScorers as ArrayList<TopScorersResponseModel>)
        }
        yellowCardList.observe(this) { yellowCard ->
            yellowCardAdapter.updateList(yellowCard as ArrayList<TopScorersResponseModel>)
        }
        redCardList.observe(this) { redCards ->
            redCardsAdapter.updateList(redCards as ArrayList<TopScorersResponseModel>)
        }
        assistsList.observe(this) { assits ->
            assistAdapter.updateList(assits as ArrayList<TopScorersResponseModel>)
        }
    }




}